<?php

$connect = mysqli_connect("localhost", "root", "11111111", "web_exam");
mysqli_set_charset($connect, "utf8");

?>